public class DiskDriver_elevator extends DiskDriver
{
	//Constants for symbolic reference. up list(>this), down list(<this).
	private static final int UP = 0;
	private static final int DN = 1;
	private              int dir;    //holds current direction.

	private PriorityQueue<DiskRequest>[] requests;

	//set up sim and the Queus for scheduling.
	public DiskDriver_elevator(DiskSimulator theSim)
	{
		super(theSim);
		requests = new PriorityQueue[2];
		requests[UP] = new PriorityQueueAsc<DiskRequest>();
		requests[DN] = new PriorityQueueDesc<DiskRequest>();
		dir = UP;
	}

	//schedule the next request in the proper direction list.
	public void schedRequest(DiskRequest dr)
	{
		if(request == null)
		{
			requests[dir].add(dr);
			nextRequest();
			procRequest();
		}
		else
		{
			requests[(dr.compareTo(request) <= 0) ? DN : UP].add(dr);
		}

	}

	//remove the next request from proper direction list.
	protected void removeRequest()
	{
		requests[dir].remove();
	}

	//retrieve the next request but dont remove.
	protected void nextRequest()
	{
		if(requests[dir].isEmpty()) dir ^= 1;
		request = (requests[dir].isEmpty()) ? null:(DiskRequest)requests[dir].get();
	}
}