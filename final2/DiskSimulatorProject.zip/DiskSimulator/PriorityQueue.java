public abstract class PriorityQueue<T> extends Queue<T>
{
	public PriorityQueue()
	{
		super();
	}
	public abstract void add(T data);
}