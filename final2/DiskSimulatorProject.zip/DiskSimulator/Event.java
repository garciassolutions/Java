public class Event implements Comparable<Event>
{
	//Declare Event Types as integer constants.
	public static final int       NEW_REQUEST = 1; //A NEW_REQUEST for a disk read/write is entered from a user process.
	public static final int    SEEK_SATISFIED = 2; //Disk driver requested arm, seek to another cylinder, SEEK_SATISFIED
	public static final int     ROT_SATISFIED = 3; //Disk driver is waiting for disk to rotate to proper sector, ROT_SATISFIED
	public static final int REQUEST_SATISFIED = 4; //The complete user request has been satisfied. REQUEST_SATISFIED
	private int  type;   //The type of request, as above.
	private long time;   //Time of the event.(future, �sec)

	public Event()
	{
	}

	//Complete constructor...Asign type, and time from request to the time of the event.
	public Event (int typeIN, long timeIN)
	{
		type = typeIN;
		time = timeIN;
	}

	//Returns this - that
	public int compareTo(Event that)
	{
		return (int)(this.time - that.time);
	}

	//this == that?
	public boolean equals(Event that)
	{
		return that.time == this.time;
	}

	//returns Type @ Time
	public String toString()
	{
		StringBuilder temp = new StringBuilder();
		switch (this.type)
		{
			case 1:
			{
				temp.append("      NEW_REQUEST:");
				break;
			}
			case 2:
			{
				temp.append("   SEEK_SATISFIED:");
				break;
			}
			case 3:
			{
				temp.append("    ROT_SATISFIED:");
				break;
			}
			case 4:
			{
				temp.append("REQUEST_SATISFIED:");
				break;
			}
			default:
			{
				temp.append("        UNDEFINED:");
				break;
			}
		}
		temp.append(" @ " + Fmt.time(time));
		return temp.toString();
	}

	//returns type of this event
	public int getType()
	{
		return this.type;
	}

	//returns scheduled execution time.
	public long getTime()
	{
		return this.time;
	}

}