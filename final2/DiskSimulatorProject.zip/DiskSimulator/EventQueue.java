//WOW...that was easy. ^_^
public class EventQueue extends PriorityQueueAsc<Event>
{
	public EventQueue()
	{
		super();
	}
}